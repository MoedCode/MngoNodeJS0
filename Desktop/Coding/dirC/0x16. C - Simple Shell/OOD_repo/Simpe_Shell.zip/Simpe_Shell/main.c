#include "main.h"
#include <stdio.h>
#include <stdlib.h>

int main(void)
{

	int interActicve = isatty(STDIN_FILENO);
	char **argv;
	argv = malloc(5);
	printf("isAtty [%d]\n",interActicve);
	/*isatty => 0 in case of interactive mode */
	if (!interActicve)
		{
			printf("File interActicve = %d\n",interActicve);
			 handelFile0();

		}

	else
	{
		write(STDIN_FILENO, "--INTER ACTIVE --\n ", 18);

		inter_Active(tokenArr);

		// printf("comd interactive = %d\n", interActicve);

	}

	return (0);
}
