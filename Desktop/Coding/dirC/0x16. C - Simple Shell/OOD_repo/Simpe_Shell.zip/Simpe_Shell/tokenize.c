#include "main.h"
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int tokenize(char *cmd, char*  delim, char **argv)
{
	size_t strTokN = 0, cmdLn = strlen(cmd), argc = 0;
	char *token = NULL;


	token = strtok(cmd, delim);
	while (token)
	{
		argc ++;
		argv = realloc(argv, argc * sizeof(char *));
		if (!argv)
		{
			free(cmd);
			perror("tokenaize.c:21 realloc");
			return (-1);
		}
		token = strtok(NULL, delim);

		strTokN++;

	}
	printf("tokNum [%zu]\n",strTokN);
	free(cmd);

}

void asignTokStrToArr2d(char *cmd, char **argv, size_t strln)
{

	size_t i;
	for (i = 0; i < strln; i++);

// free(cmd);

}
