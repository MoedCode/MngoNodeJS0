#include "main.h"
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

int inter_Active(char **argv)
{
	size_t cmdLen = 0;
	char *cmd = NULL, *Esc = "exit\n", *Esc1 = "exit";

	cmd = malloc(50);
	if (!cmd)
	{
		perror("interActive.c:15 failed to Allocat -- cmd");
		free(argv);
		return (-1);

	}



	while (1 )

	{

		write(STDIN_FILENO, "$ ", 2);
		getline(&cmd, &cmdLen, stdin);
		size_t tmp = strlen(cmd);
		printf("interActive.c:20 tmp %zu \n",tmp);
		tokenize(cmd, " \n");
		printTS(cmd,tmp);
		if ( strcmp(Esc, cmd) == 0 || strcmp(Esc1, cmd) == 0)
			break;
	}




}
