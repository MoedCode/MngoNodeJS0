#include "main.h"

char **tokenize_string(char *str, char *del)
{
	char **tokenList = malloc(sizeof(char *) * 550);
	char *token = strtok(str, del);
	int i = 0;

	while (token != NULL)
	{
		tokenList[i] = strdup(token);
		token = strtok(NULL, del);
		i++;
	}

	tokenList[i] = NULL;

	return tokenList;
}
